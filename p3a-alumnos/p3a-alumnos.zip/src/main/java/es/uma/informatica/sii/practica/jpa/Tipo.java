package es.uma.informatica.sii.practica.jpa;

public enum Tipo {
    TEXTO, NUMERO, FECHA, BOOLEANO
}
